import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore";
import { motion } from "motion/react";
import { Trophy, Medal, Crown, ArrowLeft, User as UserIcon, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

interface LeaderboardUser {
  id: string;
  name: string;
  points: number;
  email: string;
}

export default function Leaderboard() {
  const { user } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const q = query(collection(db, "users"), orderBy("points", "desc"), limit(50));
        const querySnapshot = await getDocs(q);
        const users = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as LeaderboardUser[];
        setLeaderboard(users);
      } catch (err) {
        console.error("Error fetching leaderboard:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaderboard();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-24 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto pb-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-10"
      >
        <Link to="/dashboard" className="inline-flex items-center text-orange-600 font-bold hover:underline mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Link>
        <div className="text-center">
          <h1 className="text-5xl font-black tracking-tighter text-gray-900 mb-4 uppercase">
            HALL OF <span className="text-orange-500 italic">FAME</span>
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            The strongest warriors in the Bikness community. Earn points by completing workouts and staying active.
          </p>
        </div>
      </motion.div>

      {/* Top 3 Podium */}
      {!loading && leaderboard.length >= 3 && (
        <div className="grid grid-cols-3 gap-4 mb-12 items-end">
          {/* 2nd Place */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col items-center"
          >
            <div className="relative mb-4">
              <div className="w-16 h-16 sm:w-24 sm:h-24 bg-gray-200 rounded-full border-4 border-gray-300 flex items-center justify-center text-gray-400">
                <UserIcon className="w-8 h-8 sm:w-12 sm:h-12" />
              </div>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white font-black border-2 border-white">
                2
              </div>
            </div>
            <p className="font-bold text-sm sm:text-base text-gray-900 truncate w-full text-center">{leaderboard[1].name}</p>
            <p className="text-orange-500 font-black text-xs sm:text-sm">{leaderboard[1].points} PTS</p>
          </motion.div>

          {/* 1st Place */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center"
          >
            <Crown className="text-yellow-400 w-8 h-8 mb-2 animate-bounce" />
            <div className="relative mb-4">
              <div className="w-20 h-20 sm:w-32 sm:h-32 bg-yellow-50 rounded-full border-4 border-yellow-400 flex items-center justify-center text-yellow-500">
                <UserIcon className="w-10 h-10 sm:w-16 sm:h-16" />
              </div>
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center text-white font-black border-2 border-white">
                1
              </div>
            </div>
            <p className="font-black text-base sm:text-xl text-gray-900 truncate w-full text-center">{leaderboard[0].name}</p>
            <p className="text-orange-500 font-black text-sm sm:text-lg">{leaderboard[0].points} PTS</p>
          </motion.div>

          {/* 3rd Place */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col items-center"
          >
            <div className="relative mb-4">
              <div className="w-16 h-16 sm:w-24 sm:h-24 bg-orange-50 rounded-full border-4 border-orange-300 flex items-center justify-center text-orange-400">
                <UserIcon className="w-8 h-8 sm:w-12 sm:h-12" />
              </div>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-orange-300 rounded-full flex items-center justify-center text-white font-black border-2 border-white">
                3
              </div>
            </div>
            <p className="font-bold text-sm sm:text-base text-gray-900 truncate w-full text-center">{leaderboard[2].name}</p>
            <p className="text-orange-500 font-black text-xs sm:text-sm">{leaderboard[2].points} PTS</p>
          </motion.div>
        </div>
      )}

      {/* Full List */}
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-gray-500">Loading rankings...</div>
        ) : (
          <div className="divide-y divide-gray-50">
            {leaderboard.map((lbUser, i) => (
              <motion.div
                key={lbUser.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`flex items-center justify-between p-6 hover:bg-gray-50 transition-colors ${lbUser.id === user?.uid ? 'bg-orange-50' : ''}`}
              >
                <div className="flex items-center space-x-6">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm ${
                    i === 0 ? 'bg-yellow-400 text-white' : 
                    i === 1 ? 'bg-gray-300 text-white' : 
                    i === 2 ? 'bg-orange-300 text-white' : 
                    'bg-gray-100 text-gray-500'
                  }`}>
                    {i + 1}
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center text-gray-400">
                      <UserIcon className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 flex items-center gap-2">
                        {lbUser.name}
                        {lbUser.id === user?.uid && (
                          <span className="text-[10px] bg-orange-500 text-white px-2 py-0.5 rounded-full uppercase font-black">You</span>
                        )}
                      </p>
                      <p className="text-xs text-gray-500">{lbUser.email}</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-orange-500 fill-orange-500" />
                  <span className="text-xl font-black text-gray-900">{lbUser.points || 0}</span>
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">PTS</span>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
